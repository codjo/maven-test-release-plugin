#!/bin/bash

ls -als
